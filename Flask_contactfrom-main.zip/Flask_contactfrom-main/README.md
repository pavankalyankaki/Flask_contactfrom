# Flask_contactFrom
This project aims to create a basic web based contact form using flask, a python web frame work
